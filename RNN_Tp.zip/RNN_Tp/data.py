sentences = [
    ["le","chat","que","le","chien","a","vu","mange"],
    ["le","chien","que","le","chat","poursuit","aboie"],
    ["le","chat","que","le","voisin","nourrit","dort"],
    ["le","chien","que","le","voisin","adopte","mange"],
    ["le","chat","que","le","chien","effraie","se","cache"],
    ["le","chien","que","le","chat","observe","se","nourrit"]
]
